<?php 
//Silence is golden