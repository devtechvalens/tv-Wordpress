=== WP Season Banner by AutumnLane ===
Contributors: autumnlane
Tags: banners, seasons, season banners
Requires at least: 4.0
Tested up to: 4.9
Requires PHP: 5.3
Stable tag: 1.0.0
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This plugin provide different banner for each season automatically. Shortcode: [Season_Banner].

== Description ==

A very simple plugin which provide different banner for each season automatically. Shortcode: [Season_Banner].


== Installation ==

= Minimum Requirements =

* WordPress 4.0 or greater
* PHP version 5.3 or greater

= Setting Up =

1. Activate the plugin
2. Go to UpStream > General Settings and configure the options as required
3. Create a Client by going to Projects > New Client
4. Create a Project by going to Projects > New Project
5. For a Quick Start guide and more detailed instructions, please visit the [Documentation](https://upstreamplugin.com/documentation/) page.




== Changelog ==

The format is based on [Keep a Changelog](http://keepachangelog.com)
and this project adheres to [Semantic Versioning](http://semver.org).

= [1.0.0] - 2018-11-16 =

* Initial release
